export default interface PostModelInterface {
    postName: string;
    postDescription: string;
    postingDate: number;
}